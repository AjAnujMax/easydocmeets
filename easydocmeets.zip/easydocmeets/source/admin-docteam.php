

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.containerd {
	background-color: #d9d2f4;
  padding: 0 16px;
}

.containerd::after, .row::after {
  content: "";
  clear: both;
  display: table;
  
}

.title {
  color: grey;
}

.Contactbutton {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #7b61dd;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.Contactbutton:hover {
  background-color: #71ba50;
}
</style>
</head>
<body>
<?php //include('adminpage.php'); ?>
<center>
<h1>Meet The Team</h1>
<p>"we are always ready to care you"</p>
<br>

<?php
 include('dconnect.php');

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	
?>
<form name="frm" method="post" action="admin-docteam.php">
<div class="row">
  <div class="column">
    <div class="card">
       <div class="containerd">
        <h2><?php echo "<br> DR.  ". $row["name"]."";?>
		<h3><?php echo "" . $row["degree"]."<br>"; ?></h3></h2>
		<h4 class="title"><?php echo "<br>'" . $row["msg"].  "'<br>"; ?></h4>
        <p class="title"><?php echo "<br> Practicing Since: ". $row["pyr"]. ""; ?></p>
        <p><?php echo " SPECILITY : " . $row["specility"].  "<br>AGE: " . $row["age"]." GENDER: ". $row["sex"]."<br>"; ?></p>
        <p><?php echo "<br> EMAIL : " . $row["email"].  "<br>"; ?></p>
        <p><button class="Contactbutton" name="deleteid"; value="<?php echo "".$row["id"].""; ?>">DELETE DOCTOR</button></a></p>
      </div>
    </div>
  </div>
</form>  

<?php
		}
	} 
$db->close();
?>
</div>
</body>
</html>

