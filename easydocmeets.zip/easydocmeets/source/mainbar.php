<html>
<head>
  <title>mainbar</title>
 
  <link rel="stylesheet" type="text/css" href="bar.css">
</head>
<body >
	<header>
	
		<div class="bar">
			<div class="logo">
			
			</div>
						
			<div class="site">
				<h3>EasyDocMeets</h3>
								
	        </div>	
			<ul> 
				<li ><a href="home.php">Home </a></li>
				<li><a href="Treatment.php">Treatment</a></li>
				<li> <a href="doctor.php">Doctor</a></li>
				<li> <a href="patient.php">Patient</a></li>
				<li> <a href="about.php">Feedback</a></li>
				<li> <a href="contacts.php">Contacts </a></li>
			</ul>
			
			<div>
	<?php include('logstatus.php'); ?>
	</div>
		</div>
			</header>
	<footer>
	<?php include('footer.php'); ?>
	</footer>

	
	
	
<body>
</head>
</html>	