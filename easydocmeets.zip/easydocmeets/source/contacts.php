<?php //include('contactdb.php') ?>
<html>
<head>
<title>EasyDocMeets</title>

<link rel="stylesheet" type="text/css" href="contact.css"/>


</head>
<body>
	<?php include('mainbar.php'); ?>

	<div  class="contact-form">
		<h1>Do You have a Question?<BR> Contact US </h1>
		
		<form name="frm" method="post" action="contactdb.php" >
		
		<a href="home.php"><B>HOME<B></a>
	
	
		<div class="txtb"> 
			<label>Full Name :</label>
			<input type="text" name="username" placeholder="Enter ur Name" required>
		</div>
		
		<div class="txtb"> 
			<label>Email :</label>
			<input type="text" name="email" placeholder="Enter ur Email" required>
		</div>
		
		<div class="txtb"> 
			<label>Mobile Number :</label>
			<input type="text" name="mob" placeholder="Enter ur Mobile Number" required>
		</div>
		
		<div class="txtb"> 
			<label> MESSAGE  </label>
			<textarea type="text" name="msg" rows="5" cols="10" placeholder="Enter your msg" > </textarea>
		</div>
		
		<div class="txtb">
			<label>plz select any</label>
			<input type="radio" name="type" value="feedback" required >FEEDBACK
			<input type="radio" name="type" value="query" required >QUERY
		</div>
		
		<button class="btn" type="submit" name="send"  value="submit">
		Send</button>
		
		</form>
	</div>
	</header>

</body>
</html>
