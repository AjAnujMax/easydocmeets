<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.containerd {
	background-color: #d9d2f4;
  padding: 0 16px;
}

.containerd::after, .row::after {
  content: "";
  clear: both;
  display: table;
  
}

.title {
  color: grey;
}

.Contactbutton {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #7b61dd;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.Contactbutton:hover {
  background-color: #71ba50;
}
</style>
</head>
<body>
<center>
<h1>Meet The Team</h1>
<p>"we are always ready to care you"</p>
<br>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

 $sql = "SELECT * FROM doctor ";
$result = $conn->query($sql);

//$sql = "SELECT id, username, email,degree FROM users,doctor  where users.mob=doctor.mob";
//$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
    
?>

<form name="frm" method="post" action="appointment.php">
<div class="row">
  <div class="column">
    <div class="card">
       <div class="containerd">
        <h2><?php echo "<br> Dr.  ". $row["name"]."";?></h2>
		<h3><?php echo "" . $row["degree"]; ?></h3>
		<h4 class="title"><?php echo "<br>'" . $row["msg"]."'"; ?></h4>
        <p class="title"><?php echo "Practicing Since: ". $row["pyr"]."<br>Chamber no:-" . $row["chamber"]."<br> Address-" . $row["location"].  ""; ?></p>

        <p><?php echo " Specility : " . $row["specility"].  "<br>Age: " . $row["age"]." Gender: ". $row["sex"]; ?></p>
        <p><?php echo "Email : " . $row["email"].  "<br>"; ?></p>
        <p><a href="appointment.php"><button class="Contactbutton" name="bookingid"; value="<?php echo "".$row["id"].""; ?>">BOOK APPOINTMENT</button></a></p>
      </div>
    </div>
  </div>
</form> 
<?php
		}
	} 
$conn->close();
?>
</div>
</body>
</html>

