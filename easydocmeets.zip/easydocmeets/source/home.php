<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="about.css"/>

<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
-->
</head>
<body>
	<?php include('mainbar.php'); ?>
	
	<div  class="head-form">
	     <h1> HOME </h1>
	</div>	
	
	<div class="body">
	<center>
	<br>
	<br>
		<h1>MEET YOUR DOCTOR WITHOUT WAITING FOR HOURS</h1>
		<br>
		<div class="title">
		 	<h1> WELCOME <br> YOU ALL TO OUR PORTAL</h1>
		</div>
		

		</div>
		
			
	</header>
		
	
	
	

<!--<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

--></body>
</html>
