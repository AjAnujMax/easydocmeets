<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="about.css"/>
<link rel="stylesheet" type="text/css" href="bar.css">
<link rel="stylesheet" type="text/css" href="feedback.css">


</head>
<body>
	

  

	<header>
	
		<div class="bar">
			<div class="logo">
			<img src="logodoc.jpg">
			</div>
						
			<div class="site">
				<h3>EasyDocMeets</h3>
								
	        </div>	
			<ul> 
				<li ><a href="login.php">Home </a></li>
				<li><a href="d-register.php">Add Doctor</a></li>
				<li><a href="admin-register.php">Add Admin</a></li>
				<li><a href="patientbooked.php">VIEW APPOINTMENTS</a></li>
				<li><a href="admin-docteam.php">VIEW DOCTOR</a></li>
				
			</ul>
			
		</div>
		<div>
	<?php //include('adminlogstatus.php'); ?>
	</div>
			</header>
	<footer>
	<?php include('footer.php'); ?>
	</footer>

	<div  class="head-form">
	     <h1> ADMIN PAGE </h1>
	</div>	
	
	<div class="body">
	<center>
		
		<div class="title">
		 	<h1>  <br>QUERIES   </h1>
		</div>

			
		
		
	<div>
<center>



<br>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT  username, msg FROM contactdb where type='query'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
    
?>
<div class="row">
  <div class="column">
    <div class="card">
       <div class="containerd">
        <h2><?php echo "<br> ". $row["username"]."";?> </h2>
        <p class="title">patient</p>
        <p><?php echo "Query - " . $row["msg"].  "<br><br>"; ?></p>
      </div>
    </div>
  </div>

<?php
		}
	} 
$conn->close();
?>
</div>
</div>
	
	</div>		
	</header>


</body>
</html>
