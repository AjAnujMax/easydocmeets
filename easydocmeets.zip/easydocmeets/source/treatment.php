<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="about.css"/>
</head>
<body>
	<!-- mainbar inncluded here-->
	<?php include('mainbar.php'); ?>
	<div  class="head-form">
	     <h1> TREATMENT</h1>
	</div>
	
	<!-- body part inncluded here-->
    <div class="body">
	<center>
		<h1>E-Appointment,Easy Treatment</h1>
			<div class="mid">
				<h3><br>
The EasyDocsMeets, the organization that owns the connectivity power to connect doctor patient without waiting.
				</h3>
				<br><br>
				
					</center>
				
	
	<?php include('specility.php'); ?>
	
	</div>
	</div>
	

</body>
</html>