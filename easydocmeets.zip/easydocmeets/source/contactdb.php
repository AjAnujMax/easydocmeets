<?php
session_start();

// initializing variables


// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'registration');

// TAKE INPUT INTO CONTACTDB.PHP
	if (isset($_POST['send'])) {
  // receive all input values from the form
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $mob = mysqli_real_escape_string($db, $_POST['mob']);
  $msg = mysqli_real_escape_string($db, $_POST['msg']);
  $type = mysqli_real_escape_string($db, $_POST['type']);
  
  $query = "INSERT INTO contactdb (username, mob, email, msg, type) 
  			  VALUES('$username','$mob','$email','$msg','$type')";
 mysqli_query($db, $query); 
}
include('home.php');
?>
<head>
  <link rel="stylesheet" type="text/css" href="contact.css">

</head>
<body>
<div class="contact-form"></h3>
		<h1>THANK YOU </h1><br>
		<a href="home.php" class="logbtn">OK</a>
</body>