<?php include('adminserver.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome to EasyDocMeets</title>
 
  <link rel="stylesheet" type="text/css" href="contact.css">
   
  
</head>
<body>
<!--Main menu Bar	-->
		<?php include('firstpage.php'); ?>
	<!--login form	-->	

<div class="contact-form"></h3>
		<h1>ADMIN-LOGIN</h1>
   
<form name="frm" method="post" action="adminpage.php">

	<?php include('adminerrors.php'); ?>
	
  	<div class="txtb">
  		<label>Mobile no</label>
  		<input type="text" name="mob" placeholder="Enter Mobile no"  >
  	</div>
	
  	<div class="txtb">
  		<label>Password</label>
  		<input type="password" name="password" placeholder="Enter Password"  >
  	</div>
	
	<button type="submit" class="btn" name="login_user">Login</button>
  	
  	<p>
  		USER LOGIN? <a href="login.php">LOGIN</a>
  	</p>
  </form>
  </div>
  
  </header>
</body>
</html>