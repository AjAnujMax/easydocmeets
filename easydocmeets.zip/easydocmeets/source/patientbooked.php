<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
html {
  box-sizing: border-box;
}
.body{
bgcolor:#99FF99;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.containerd {
	background-color: #d9d2f4;
  padding: 0 16px;
}

.containerd::after, .row::after {
  content: "";
  clear: both;
  display: table;
  
}

.title {
  color: grey;
}

.Contactbutton {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #7b61dd;
  text-align: center;
  cursor: pointer;
  width: 100%;
}
.backgrdcolor{
background-color:#99FF99;	
}

.Contactbutton:hover {
  background-color: #71ba50;
}
</style>
</head>
<body>
<div class="backgrdcolor">
<center>
<h1>BOOKED APPOINTMENTS</h1>
<br>

<?php
// Create connection
$db = new mysqli('localhost', 'root', '', 'registration');
// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} 
$logname=$_SESSION['username'];
$sql = "SELECT * FROM appointment where ref_user_name='$logname'";
$result = $db->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	
?>
<form name="frm" method="post" action="patient.php">
<div class="row">
  <div class="column">
    <div class="card">
       <div class="containerd">
        <h2><?php echo "<br> Patient Name:  ". $row["pname"]."";?>
		</h2>
        <p class="title"><?php echo "<br> Doctor :". $row["id"]. ""; ?></p>
        <p><?php echo "<br> Mob : " . $row["pmob"].  "<br>"; ?></p>
        <p><a href="delete_patient.php?id=<?php echo $row['id'];?>" class="Contactbutton">
		CANCEL APPOINTMENT</a></p>
      
	  
	  
	  
	  
	  </div>
    </div>
  </div>
</form>  

<?php
		}
	}
else{
	echo "NO APPOINTMENT BOOKED YET!!";
}	
$db->close();
?>
<br>
<p>.
<div>
<br><br><br><br><br>
<p>.
</div>
</div>
</div >
</body>
</html>

