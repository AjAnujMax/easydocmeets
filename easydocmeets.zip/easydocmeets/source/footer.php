<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.fixed-footer{
        width: 100%;
        position: fixed;        
        background: #003333;
        padding: 10px 0;
        color: #fff;
		opacity: 0.3;
		 bottom: 0;
    }

.fixed-footer:hover {
    opacity: 50.0;
}	
.container{
        width: 95%;
        margin: 0 auto; /* Center the DIV horizontally */
    }
	
.fa {
  padding: 5px;
  font-size: 10px;
  width: 10px;
  text-align: center;
  text-decoration: none;
  margin: 2px 1px;
}
.fa:hover {
    opacity: 0.7;
}
.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}	
.fa-yahoo {
  background: #430297;
  color: white;
}
.fa-instagram {
  background: #125688;
  color: white;
}	
</style>
</head>
<body>
<div class="fixed-footer">
        <div class="container">Copyright &copy; 2020 EasyDocMeets        
 	<a href="https://fb.com" class="fa fa-facebook"></a>
	<a href="https://www.instagram.com/accounts/login/" class="fa fa-instagram"></a>
	<a href="https://twitter.com/login" class="fa fa-twitter"></a>
	<a href="https://www.google.com/" class="fa fa-google"></a>
	<a href="https://in.yahoo.com/" class="fa fa-yahoo"></a>
	</div>
	</div>
	
</body>
</html>