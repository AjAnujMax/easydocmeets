<?php
session_start();
extract($_GET);
$db = new mysqli('localhost', 'root', '', 'registration');
// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} 
$logname=$_SESSION['username'];
$sql = "delete FROM appointment where id='$id'";
$result = $db->query($sql);
header("location:patient.php");
?>
