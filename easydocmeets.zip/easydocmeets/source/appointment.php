
<?php include('appointmentdb.php'); ?>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
 
  <link rel="stylesheet" type="text/css" href="contact.css">
   
  
</head>
<body>
<!--Main menu Bar	-->
	<!--appointment form	-->	

<div class="contact-form"></h3>
		<h1>Book Apointment</h1>
   
<form name="frm" method="post" action="appointmentdb.php">
	
	<a href="doctor.php">CLOSE</a>
	<h1><?php
		   include('dconnect.php'); 
  $bookingid =$_POST['bookingid'];
	$sql = "SELECT name,id FROM doctor where id='$bookingid'";
$result = $db->query($sql);
$row = $result->fetch_assoc();
	echo "DR. ". $row["name"];
	
	?>
	</h1>
	
	
  	<div class="txtb">
	
  		<label>patient name</label>
  		<input type="text" name="name" placeholder="Enter Patient name" required>
  	</div>
	<div class="txtb">
  		<label>Mobile no</label>
  		<input type="text" name="mob" placeholder="Enter Mobile no" required >
  	</div>
	<button type="submit" class="btn" name="ConfirmBookid" value="<?php echo "".$row["id"]."";?>">Confirm Booking</button>
  	
	
	
  </form>
  </div>
  

  </header>
</body>
</html>