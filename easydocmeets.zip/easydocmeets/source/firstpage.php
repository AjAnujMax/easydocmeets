<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="about.css"/>
<link rel="stylesheet" type="text/css" href="bar.css">



</head>
<body>
	

  

	<header>
	
		<div class="bar">
			<div class="logo">
			<img src="logodoc.jpg">
			</div>
						
			<div class="site">
				<h3>EasyDocMeets</h3>
								
	        </div>	
			<ul> 
				<li ><a href="login.php">Home </a></li>
				<li><a href="login.php">Treatment</a></li>
				<li><a href="login.php">Doctor</a></li>
				<li><a href="login.php">Patient</a></li>
				<li><a href="login.php">About</a></li>
				<li><a href="login.php">Contacts </a></li>
			</ul>
			
		</div>
			</header>
	<footer>
	<?php include('footer.php'); ?>
	</footer>
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	<div  class="head-form">
	     <h1> LOGIN or REGISTER </h1>
	</div>	
	
	<div class="body">
	<center>
		<h1>MEET YOUR DOCTOR WITHOUT WAITING FOR HOURS</h1>
		<br>
		<div class="title">
		 	<h1> WELCOME <br> YOU ALL TO OUR PORTAL</h1>
		</div>
		<h1>CHAIRMAN'S MESSAGE<h1>
		<br>
		<img src="anuj.jpg">
		<h1> Anuj kumar Mahato<h1>
		<br>
		<h2>Text</h2>

		</div>
			
	</header>
		
	
	
	


</body>
</html>
