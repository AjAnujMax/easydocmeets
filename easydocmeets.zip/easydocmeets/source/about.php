<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="about.css"/>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="feedback.css">
</head>
<body>
	<?php include('mainbar.php'); ?>
	<div  class="head-form">
	     <h1> FEEDBACKS</h1>
	</div>
	<div class="body">
	<center>
		
		<br>
		<div class="title">
		<h4>MEET YOUR DOCTOR WITHOUT WAITING FOR HOURS</h4>
		 	<h1>FEEDBACKS</h1>
			
			<h3 >"Our patients Speak"</h3>
		</div>
		
		<div>
<center>



<br>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT  username, msg FROM contactdb where type='feedback'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
    
?>
<div class="row">
  <div class="column">
    <div class="card">
       <div class="containerd">
        <h2><?php echo "<br> ". $row["username"]."";?> </h2>
        <p class="title">patient</p>
        <p><?php echo "Feedback - " . $row["msg"].  "<br><br>"; ?></p>
      </div>
    </div>
  </div>

<?php
		}
	} 
$conn->close();
?>
</div>
</div>
	
	
	
	
	
	
	
</body>
</html>
