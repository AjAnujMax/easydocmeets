<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome to EasyDocMeets</title>
 
  <link rel="stylesheet" type="text/css" href="contact.css">
   
  
</head>
<body>
<!--Main menu Bar	-->
		<?php include('firstpage.php'); ?>
	<!--login form	-->	

<div class="contact-form"></h3>
		<h1>Login</h1>
   
<form name="frm" method="post" action="login.php">

	<?php include('errors.php'); ?>
	
  	<div class="txtb">
  		<label>Mobile no</label>
  		<input type="text" name="mob" placeholder="Enter Mobile no"  >
  	</div>
	
	
  	<div class="txtb">
  		<label>Password</label>
  		<input type="password" name="password" placeholder="Enter Password"  >
  	</div>
	
	<button type="submit" class="btn" name="login_user">Login</button>
  	
  	<p>
  		Not yet a member? <a href="register.php">SIGN UP<br></a><a href="adminlogin.php">ADMIN-LOGIN</a>
  	</p>
  </form>
  </div>
  
  </header>
</body>
</html>