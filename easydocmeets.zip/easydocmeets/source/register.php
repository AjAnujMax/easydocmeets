<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="contact.css">
   
</head>
<body>
	<?php include('firstpage.php'); ?>

  	
  
	
	<div class="contact-form">
	<h1>Register</h1>
  <form name="frm" method="post" action="register.php">
  	<?php include('errors.php'); ?>
			 	
	<div class="txtb">
  	  <label>Patient name</label>
  	  <input type="text" name="username" value="<?php echo $username; ?>" placeholder="Enter Patient Name" required >
  	</div>
	<div class="txtb">
  	  <label>MObile no.</label>
  	  <input type="text" name="mob" value="<?php echo $mob; ?>" placeholder="Enter Mobile no." required>
  	</div>
  	<div class="txtb">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>" placeholder="Enter Email"  required>
  	</div>
  	<div class="txtb">
  	  <label>Password</label>
  	  <input type="password" name="password_1" placeholder="Enter alpha-numeric Password" required>
  	</div>
  	<div class="txtb">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2" placeholder="Confirm Password" required>
  	</div>
	
  	
	<button type="submit" class="btn" name="reg_user">Register</button>
  	<p>
  		Already have account? <a href="login.php">Login</a>
  	</p>
  </form>
  </div>
  
  
 
</body>
</html>