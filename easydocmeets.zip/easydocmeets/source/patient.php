<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="about.css"/>
</head>
<body>
	<?php include('mainbar.php'); ?>
	
	
	<div  class="head-form">
			<h1><center> PATIENT INFOMATION</center></h1>
	</div>
    	
	<div class="body">
			<center>
			<br><br>
			<h1>OUR MANY PATIENT--UR DOCTOR </h1>
			<div class="mid">
				<H2> WE PRAY,YOU REVIVE SOON IN OUR HOSPITALS  
				</H2>
			</center>
			<br><br><br>
	
		<?php include('patientbooked.php'); ?>
	
	</div>
</div>
</body>
</html>
