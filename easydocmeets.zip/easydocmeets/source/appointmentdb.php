<?php 
$db = mysqli_connect('localhost', 'root', '', 'registration');
if (isset($_POST['ConfirmBookid'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $mob = mysqli_real_escape_string($db, $_POST['mob']);
  //$dname = mysqli_real_escape_string($db, $_POST['dname']);
  $ConfirmBookid = mysqli_real_escape_string($db, $_POST['ConfirmBookid']);
  extract($_GET);
  $logname=$_SESSION['username'];
  
   $query = "INSERT INTO appointment ( pname, pmob, dID, ref_user_name)
			VALUES('$name','$mob','$ConfirmBookid','$logname')";
mysqli_query($db, $query);
}
$db->close();
 include('doctor.php');
?>
<head>
  <link rel="stylesheet" type="text/css" href="contact.css">

</head>
<body>
<div class="contact-form">
		<h1>BOOKING DONE</h1><br>
		<a href="patient.php" class="logbtn">OK</a></h3></div>
</body>
