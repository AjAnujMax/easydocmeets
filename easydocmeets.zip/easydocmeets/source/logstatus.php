
<?php 
  session_start(); 
	if (!isset($_SESSION['username'])) {
  	echo $_SESSION['msg'] = "You must log in first";
  	header("location: login.php");
  }
  
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="logstatus.css"/>
</head>
<body>
<div class="boxlog">
	<div class="headerlog">
	<h4>LOG INFO</h4>
</div>
<div class="contentlog">	
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
		
    	<p><center><h5><?php echo $_SESSION['username']; ?></h5></center></p>
		
    	<p><center><a href="logstatus.php?logout='1'" style="color: red;">logout</a></center> </p>
   
	<?php endif ?>
	
</div></div>	



</body>
</html>
