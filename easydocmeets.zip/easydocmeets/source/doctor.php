<html>
<head>
<title>EasyDocMeets</title>
<link rel="stylesheet" type="text/css" href="body.css"/>
<link rel="stylesheet" type="text/css" href="about.css"/>
</head>
<body>
	<?php include('mainbar.php'); ?>
	<div  class="head-form">
		<h1> Doctor </h1>    	
	</div>
    	<div class="body">
		<center>
		<h1>"msg-UR DOC </h1>
		<BR>
		<h1>OUR MISSION </h1>
			<div class="mid">
			<h2>
Our mission is to deliver high quality, affordable healthcare services to the broader population in country. 
Our core values are represented by the acronym "e-Care".
At the same time, we seek to generate a strong healthy society...</h2>
			</div>
			
		</center>	
		
		
		
		
		
		<center>
		<?php include('docteam2.php'); ?>
</div>
</body>
</html>