<?php
session_start();

// initializing variables
 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'registration');

// TAKE INPUT INTO doctor.PHP
	if (isset($_POST['submit'])) {
  // receive all input values from the form
  $dname = mysqli_real_escape_string($db, $_POST['dname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $mob = mysqli_real_escape_string($db, $_POST['mob']);
  $specility = mysqli_real_escape_string($db, $_POST['specility']);
  $degree = mysqli_real_escape_string($db, $_POST['degree']);
  $pyr = mysqli_real_escape_string($db, $_POST['pyr']);
  $sex = mysqli_real_escape_string($db, $_POST['sex']);
  $age = mysqli_real_escape_string($db, $_POST['age']);
  $location = mysqli_real_escape_string($db, $_POST['location']);
  $msg = mysqli_real_escape_string($db, $_POST['msg']);
  $chamber = mysqli_real_escape_string($db, $_POST['chamber']);
 
  
  $query = "INSERT INTO doctor ( name, email, mob, specility, degree, pyr, sex, age, location, msg,chamber) 
  			  VALUES('$dname','$email','$mob','$specility','$degree','$pyr','$sex','$age','$location','$msg','$chamber')";
 mysqli_query($db, $query); 
}
$db->close();
include('DOCTOR.php');
?>
<head>
  <link rel="stylesheet" type="text/css" href="contact.css">

</head>
<body>
<div class="contact-form"></h3>
		<h1>SUCCESSFULLY DOCTOR ADDED </h1><br>
		<a href="doctor.php" class="logbtn">OK</a>
</body>