<?php// include('doctordb.php'); ?>
<html>
<head>
<title>EasyDocMeets</title>

<link rel="stylesheet" type="text/css" href="register.css"/>
 <link rel="stylesheet" type="text/css" href="contact.css">
</head>
<body>
	<?php include('adminpage.php'); ?>
    			
		<div  class="register-form">
		<h1><center> REGISTRATION FORM </center></h1>
		<form name="frm" method="post" action="doctordb.php">
		
		<div class="txtb"> 
			<label>DOCTOR FULL NAME:</label>
			<input type="text" name="dname" placeholder="Enter Doctor Name" required>
		</div>
		
		<div class="txtb"> 
			<label>SPECILITY :</label>
			<input type="text" name="specility" placeholder="Enter Doctor SPECILITYs" required>
		</div>
		
		<div class="txtb"> 
			<label>QUALICICATIONS :</label>
			<input type="text" name="degree" placeholder="All QUALIFICATIONs example:- m.b.b.s, md" required>
		</div>
		
		<div class="txtb"> 
			<label>PRACTICING STARTING YEAR :</label>
			<input type="number" name="pyr" maxlength="3" placeholder="Year. example:-2010" required>
		</div>
								
		<div class="txtb"> 
			<label>Mobile Number :</label>
			<input type="number" name="mob" placeholder="Enter Doctor Mobile Number" required>
		</div>
		
		<div class="txtb"> 
			<label>Email :</label>
			<input type="text" name="email" placeholder="Enter Doctor Email" required>
		</div>
		
		<div class="txtb"> 
			<label>SEX :</label>
					<INPUT TYPE="RADIO" Name="sex" value="MALE" >MALE <INPUT TYPE="RADIO" Name="sex" value="FEMALE">FEMALE
		</div>		
		
		<div class="txtb"> 
			<label>AGE :</label>
			<input type="number" name="age"value" size="2" maxlength="2"  placeholder="Enter Doctor Age" required>
		</div>
		
		<div class="txtb"> 
			<label>Chamber name</label>
			<input type="number" name="chamber" value"  placeholder="Enter Chamber name" required>
		</div>
				
		<div class="txtb"> 
			<label>Chamber Address:</label>
					<center>
					<select name="location" required>
					<option >Select location </option>
					<option value="BARDHHAMAN">BARDHHAMAN</option>
					<option value="PANAGHAR">PANAGHAR</option>
					<option value="RAJBANDH">RAJBANDH</option>
					<option value="MUCHIPARA">MUCHIPARA</option>
					<option value="CITY CENTER">CITY CENTER</option>
					<option value="BENACHITY">BENACHITY</option>
					<option value="ANDAL">ANDAL</option>
					<option value="RANIGANJ">RANIGANJ</option>
					<option value="ASANSOL N">ASANSOL N</option>
					<option value="ASANSOL S">ASANSOL S</option>
					<option value="BARAKAR">BARAKAR</option>
					<option value="CHITTRANJAN">CHITTRANJAN</option>
					</select></center>
		</div>		
			
		
		
		<div class="txtb"> 
			<label>MESSAGE FROM DOCTOR </label>
			<textarea type="text" name="msg" rows="5" cols="10" placeholder="Enter your msg to patient" required></textarea>
		</div>
		
		<div class="txtb"> 
			<label>PASSWORD :</label>
			<input type="password" name="ps1" placeholder="Enter AlPHA-NUMERIC password" required>
		</div>
		
		<div class="txtb"> 
			<label>REPEAT PASSWORD :</label>
			<input type="password" name="ps2" placeholder="Enter SAME password" required>
		</div>
				
		<div class="txtb">
		<label>
        Remember me<input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px" required> 
		</label>
		<p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>
		</div>
		
		<div>
		<button class="btn" type="submit" name="submit" value="submit">
		Register</button>
		</div>
		
		<div>
		<a href="adminpage.php"><button class="btn">CANCEL</button></a>
		</div>
		<p>
		<p>
		</form>
    </div>
</body>
</html>